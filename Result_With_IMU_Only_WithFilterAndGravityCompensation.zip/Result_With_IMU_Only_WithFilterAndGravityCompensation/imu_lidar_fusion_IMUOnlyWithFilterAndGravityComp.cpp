#include "ros/ros.h"
#include "sensor_msgs/PointCloud2.h"
#include "sensor_msgs/Imu.h"

#include <pcl/point_types.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/registration/icp.h>
#include <pcl/common/pca.h>
#include <pcl/common/common.h>
#include <pcl/registration/correspondence_estimation.h>

#include <Eigen/Dense>
#include <Eigen/Geometry>

#include <iostream>
#include <fstream>

using namespace Eigen;

void lidarOdomCallback(sensor_msgs::PointCloud2::ConstPtr inputCloud);
void imuCallback(sensor_msgs::Imu::ConstPtr inputImu);

int corrSize = 0;

double initialTime = 0;
float initialXVelo = 0;
float initialYVelo = 0;
float initialZVelo = 0;

int n = 0;
float meanYaw = 0;
float meanRoll = 0;
float meanPitch = 0;

double m2Yaw = 0;
double m2Pitch = 0;
double m2Roll = 0;

Eigen::Quaternionf initialq;

bool imuFlag = true;
bool firstTime = true;

pcl::PointCloud<pcl::PointXYZ>::Ptr prevCloud (new pcl::PointCloud<pcl::PointXYZ>);

Matrix4f imuTransform = Matrix4f::Identity();
Matrix4f initialPose = Matrix4f::Identity();
Matrix4f kittiImuTransform = Matrix4f::Zero();

Matrix3f yawOrientation = Matrix3f::Identity(); 
Matrix3f pitchOrientation = Matrix3f::Identity(); 
Matrix3f rollOrientation = Matrix3f::Identity(); 

float totalYaw;
float totalPitch;
float totalRoll;

Matrix3f baseOrientation;

float oldPitch = 0;
float oldRoll = 0;

std::list<Eigen::Matrix4f> imuBuffer;
std::list<Eigen::Matrix4f> kittiImuBuffer;

float initialYaw = 0;
float initialPitch = 0;
float initialRoll = 0;

int divergeCount = 0;

ros::Publisher currentCloudPub;
ros::Publisher prevCloudPub;
ros::Publisher imuCloudPub;
ros::Publisher alignedCloudPub;

int main(int argc, char **argv)
{
  std::cout << "Starting Subscriber" << std::endl;
  ros::init(argc, argv, "imu_lidar_fusion");
  ros::NodeHandle n;

  ros::Subscriber imuSub = n.subscribe("/kitti/oxts/imu", 1500, imuCallback);
  ros::Subscriber pointCloudSub = n.subscribe("/kitti/velo/pointcloud", 1500, lidarOdomCallback);

  currentCloudPub = n.advertise<sensor_msgs::PointCloud2>("currentCloud", 10, true);
  prevCloudPub = n.advertise<sensor_msgs::PointCloud2>("prevCloud", 10, true);
  imuCloudPub = n.advertise<sensor_msgs::PointCloud2>("imuCloud", 10, true);
  alignedCloudPub = n.advertise<sensor_msgs::PointCloud2>("alignedCloud", 10, true);
  ros::spin();

  return 0;
}

void lidarOdomCallback(sensor_msgs::PointCloud2::ConstPtr inputCloud)
{
  std::cout << "Starting ICP" << std::endl;
  pcl::PointCloud<pcl::PointXYZ>::Ptr filteredCloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::fromROSMsg(*inputCloud, *filteredCloud);

  double maxRange = std::numeric_limits<double>::max();
  double minRange = -std::numeric_limits<double>::max();
  std::vector<int> index;
  pcl::removeNaNFromPointCloud(*filteredCloud, *filteredCloud, index);

  pcl::VoxelGrid<pcl::PointXYZ> voxel_grid;
  voxel_grid.setMinimumPointsNumberPerVoxel(10);
  voxel_grid.setInputCloud (filteredCloud);
  voxel_grid.setDownsampleAllData(false);
  voxel_grid.setLeafSize (0.5f, 0.5f, 0.5f);
  voxel_grid.filter(*filteredCloud);

  pcl::PassThrough<pcl::PointXYZ> pass_x;
  pass_x.setFilterFieldName("x");
  pass_x.setFilterLimits(minRange, maxRange);
  pcl::PassThrough<pcl::PointXYZ> pass_y;
  pass_y.setFilterFieldName("y");
  pass_y.setFilterLimits(minRange, maxRange);
  pcl::PassThrough<pcl::PointXYZ> pass_z;
  pass_z.setFilterFieldName("z");
  pass_z.setFilterLimits(minRange, maxRange);

  pass_x.setInputCloud(filteredCloud->makeShared());
  pass_x.filter(*filteredCloud);
  pass_y.setInputCloud(filteredCloud->makeShared());
  pass_y.filter(*filteredCloud);
  pass_z.setInputCloud(filteredCloud->makeShared());
  pass_z.filter(*filteredCloud);

  pcl::PointCloud<pcl::PointXYZ>::Ptr alignedCloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::PointCloud<pcl::PointXYZ>::Ptr imuCloud (new pcl::PointCloud<pcl::PointXYZ>);

  Eigen::Matrix4f currentPose;
  if (prevCloud->size() > 0 && imuBuffer.size() > 0)
  {
    pcl::transformPointCloud (*prevCloud, *imuCloud, imuBuffer.front());
    
    Eigen::Matrix4f icpTransform;
    if (imuBuffer.size()>0)
    {
      Eigen::Matrix4f finalTransform = Matrix4f::Identity();
      std::cout << "Correspondence OK: " << corrSize << std::endl;
    
      finalTransform = imuBuffer.front();
      imuBuffer.pop_front();

      currentPose.block(0,0,3,3) =  initialPose.block(0,0,3,3) * finalTransform.block(0,0,3,3);

      Vector3f gravVec (0,0,9.81);
      Vector3f sensorGrav;
      sensorGrav = currentPose.block(0,0,3,3).transpose()*gravVec;
      
      float accX = finalTransform(0,3) + sensorGrav[0];
      float accY = finalTransform(1,3) - sensorGrav[1];
      float accZ = finalTransform(2,3) - sensorGrav[2];

      float interval = finalTransform (3,3);

      float x = initialXVelo * interval + 0.5 * accX * pow(interval, 2);
      float y = initialYVelo * interval + 0.5 * accY * pow(interval, 2);
      float z = initialZVelo * interval + 0.5 * accZ * pow(interval, 2);

      Vector3f sensorTranslation;
      sensorTranslation[0] = x;
      sensorTranslation[1] = y;
      sensorTranslation[2] = z;

      Vector3f worldTranslation = currentPose.block(0,0,3,3)*sensorTranslation;

      currentPose(0,3) = worldTranslation[0] + initialPose(0,3);
      currentPose(1,3) = worldTranslation[1] + initialPose(1,3);
      currentPose(2,3) = worldTranslation[2] + initialPose(2,3); 

      initialXVelo = initialXVelo + accX * interval;
      initialYVelo = initialYVelo + accY * interval;
      initialZVelo = initialZVelo + accZ * interval;

      std::cout << "Fitness Score: " << icp.getFitnessScore() << std::endl;

      std::ofstream file;
      file.open ("2011_10_03_drive_0027_sync.txt", std::ios::app);
      for (int i = 0; i <= currentPose.rows()-2; i++)
      {
        for (int j = 0; j <= currentPose.cols()-1; j++)
        {
          file << currentPose(i,j) << " ";
        }
      }
      file << std::endl;
    }
    else
    {
      divergeCount++;
      std::cout << "ICP did not converge" << std::endl;
      std::cout << "Divergent Count: " << divergeCount << std::endl;
    }

    for (int i=0; i<=3; i++)
    {
      for (int j=0; j<=3; j++)
      {
        initialPose(i,j) = currentPose(i,j);
      }
    }
    sensor_msgs::PointCloud2 filteredCloudMsg;
    sensor_msgs::PointCloud2 prevCloudMsg;
    sensor_msgs::PointCloud2 imuCloudMsg;
    sensor_msgs::PointCloud2 alignedCloudMsg;

    pcl::toROSMsg(*filteredCloud.get(), filteredCloudMsg);
    pcl::toROSMsg(*prevCloud.get(), prevCloudMsg);
    pcl::toROSMsg(*imuCloud.get(), imuCloudMsg);
    pcl::toROSMsg(*alignedCloud.get(), alignedCloudMsg);

    currentCloudPub.publish(filteredCloudMsg);
    prevCloudPub.publish(prevCloudMsg);
    imuCloudPub.publish(imuCloudMsg);
    alignedCloudPub.publish(alignedCloudMsg);
  }
  else
  {
    currentPose = Matrix4f::Identity();
    std::ofstream file;
    file.open ("2011_10_03_drive_0027_sync.txt", std::ios::app);
    for (int i = 0; i <= currentPose.rows()-2; i++)
    {
      for (int j = 0; j <= currentPose.cols()-1; j++)
      {
        file << currentPose(i,j) << " ";
      }
    }
    file << std::endl;

    std::cout << "IMU Buffer empty" << std::endl;
  }

  prevCloud->clear();
  pcl::copyPointCloud(*filteredCloud,*prevCloud);
  std::cout << "replicate pose" << std::endl;
}

void imuCallback (sensor_msgs::Imu::ConstPtr inputImu)
{
  float yawAngle, pitchAngle, rollAngle; //axis z,y,x
  float accX, accY, accZ;
  float x, y, z;
  float kittiYawAngle;

  double currentTime = inputImu -> header.stamp.sec + inputImu -> header.stamp.nsec / pow(10,9);
  std::cout << "Current Time: " << currentTime << std::endl;
  if (initialTime != 0)
  {
    float interval = float(currentTime - initialTime);

    yawAngle = inputImu->angular_velocity.z * interval;// - baseVector[0]; //z angle
    pitchAngle = inputImu->angular_velocity.y * interval;//  - baseVector[1]; //y angle
    rollAngle = inputImu->angular_velocity.x * interval;// - baseVector[2]; //x angle

    std::cout << "Old Yaw Angle: " << yawAngle << std::endl;
    std::cout << "Old Pitch Angle: " << pitchAngle << std::endl;
    std::cout << "Old Roll Angle: " << rollAngle << std::endl;

    accX = inputImu->linear_acceleration.x; 
    accY = inputImu->linear_acceleration.y; 
    accZ = inputImu->linear_acceleration.z; 

    std::ofstream file;
    file.open ("angle.txt", std::ios::app);
    file << yawAngle << " " << pitchAngle << " " << rollAngle << std::endl;

    totalYaw += yawAngle;
    totalPitch += pitchAngle;
    totalRoll += rollAngle;

    float meanYaw = totalYaw/n;
    float meanPitch = totalPitch/n;
    float meanRoll = totalRoll/n;

    std::cout << "Mean Yaw: " << meanYaw << std::endl;
    std::cout << "Mean Pitch: " << meanPitch << std::endl;
    std::cout << "Mean Roll: " << meanRoll << std::endl;

    m2Yaw += pow(yawAngle,2);
    m2Pitch += pow(pitchAngle,2);
    m2Roll += pow(rollAngle,2);

    std::cout << "Var Yaw: " << (m2Yaw/n)-pow(meanYaw,2) << std::endl;
    std::cout << "Var Pitch: " << (m2Pitch/n)-pow(meanPitch,2) << std::endl;
    std::cout << "Var Roll: " << (m2Roll/n)-pow(meanRoll,2) << std::endl;

    n++;

    if (abs(pitchAngle) >= 0.0025) //25% confidence interval
    {
      if (pitchAngle>0)
      {
        pitchAngle = 0.001265;
      }
      else
      {
        pitchAngle = -0.001265;
      }
    }

    if (abs(rollAngle) >= 0.0021) //25% confidence interval
    {
      if (rollAngle>0)
      {
        rollAngle = 0.00107;
      }
      else
      {
        rollAngle = -0.00107;
      }
    }


    std::cout << "Yaw Angle: " << yawAngle << std::endl;
    std::cout << "Pitch Angle: " << pitchAngle << std::endl; 
    std::cout << "Roll Angle: " << rollAngle << std::endl;

    Matrix3f yaw = Matrix3f::Identity(); 
    Matrix3f pitch = Matrix3f::Identity(); 
    Matrix3f roll = Matrix3f::Identity(); 

    yaw(0,0) = cos(yawAngle);
    yaw(0,1) = -sin(yawAngle);
    yaw(1,0) = sin(yawAngle);
    yaw(1,1) = cos(yawAngle);

    pitch(0,0) = cos(pitchAngle);
    pitch(0,2) = sin(pitchAngle);
    pitch(2,0) = -sin(pitchAngle);
    pitch(2,2) = cos(pitchAngle);

    roll(1,1) = cos(rollAngle);
    roll(1,2) = -sin(rollAngle);
    roll(2,1) = sin(rollAngle);
    roll(2,2) = cos(rollAngle);

    Matrix3f rotationMatrix = yaw*pitch*roll;

    //IMU to ICP input conversion
    Vector4f acceleration;
    translation[0] = accX;
    translation[1] = accY;
    translation[2] = accZ;
    translation[3] = interval; 

    imuTransform.block(0,0,3,3) = rotationMatrix; 
    imuTransform.col(3) = acceleration;

    imuBuffer.push_back(std::move(imuTransform));
  }
  else
  {
    initialq.x() = inputImu->orientation.x;
    initialq.y() = inputImu->orientation.y;
    initialq.z() = inputImu->orientation.z;
    initialq.w() = inputImu->orientation.w;

    baseOrientation = initialq.normalized().toRotationMatrix();
    //initialPose.block(0,0,3,3) = baseOrientation.inverse();
    
    imuBuffer.push_back(std::move(Matrix4f::Identity()));
  }
  initialTime = currentTime;
}
